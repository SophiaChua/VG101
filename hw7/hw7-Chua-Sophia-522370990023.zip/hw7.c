#include <stdio.h>
#include <string.h>
#include <stdlib.h>
// You can include libraries you need

// You can write other custom functions
typedef struct {
    char name[10][256]; 
    int grade[10]; 
} student; 

// hw7 - finish this function
void sortscores(char str[]) {
    student s;
    char *token; 
    char hold[256], buffer[256]; 
    int temp;
    int i = 0, j = 0; 

    token = strtok(str, " "); 
    strcpy(s.name[i++], token); 

    while (token != NULL)
    {
        token = strtok(NULL, " "); 
        s.grade[j++] = atoi(token); 
        token = strtok(NULL, " "); 
        if (token != NULL)
            strcpy(s.name[i++], token); 
    }

    //sort 
    for (int n = 0; n < j; n++){
        for (int b = n + 1; b < j; b++){
            if (s.grade[n] < s.grade[b])
            {
                temp = s.grade[n];
                s.grade[n] = s.grade[b]; 
                s.grade[b] = temp; 
                strcpy(hold, s.name[n]); 
                strcpy(s.name[n], s.name[b]); 
                strcpy(s.name[b], hold); 
            }
        }
    }

    //print
    strcpy(str, ""); 
    for (int m = 0; m < j; m++)
    {
        sprintf(buffer, "%s %d ", s.name[m], s.grade[m]); 
        strcat(str, buffer); 
    }
}

// Do NOT change the following lines of code!!!
int main() {
    char str[256];
    scanf("%[^\n]%*c", str);  // ask for the user input
    sortscores(str);
    printf("%s\n", str);  // output
    return 0;
}
