#include <iostream>
#include <fstream>

using namespace std; 

int main() {

    int num = 0; 
    char ch; 
    char prev = 'x'; 

    ifstream in("P4.txt"); 

    while(in) {
        in.get(ch); 
        if (ch == ' ' && prev != ' ' && prev != '\n') {
            num++; 
        }
        else if (ch == '\n' && prev != '\n' && prev != ' ') {
            num++; 
        }
        prev = ch; 
    }

    cout << num << endl; // num is the total number of words in P4.txt

    in.close();
}